# frozen_string_literal: true

module Bundler
  class Source
    class Git
      class GitNotInstalledError < GitError
        def initialize
          msg = String.new
          msg << "You need to install git to be able to use gems from git repositories. "
          msg << "For help installing git, please refer to GitHub's tutorial at https://help.github.com/articles/set-up-git"
          super msg
        end
      end

      class GitNotAllowedError < GitError
        def initialize(command)
          msg = String.new
          msg << "Bundler is trying to run `#{command}` at runtime. You probably need to run `bundle install`. However, "
          msg << "this error message could probably be more useful. Please submit a ticket at https://github.com/ruby/rubygems/issues/new?labels=Bundler&template=bundler-related-issue.md "
          msg << "with steps to reproduce as well as the following\n\nCALLER: #{caller.join("\n")}"
          super msg
        end
      end

      class GitCommandError < GitError
        attr_reader :command

        def initialize(command, path, extra_info = nil)
          @command = command

          msg = String.new("Git error: command `#{command}`")
          msg << " in directory #{path}" if path
          msg << " has failed."
          msg << "\n#{extra_info}" if extra_info
          super msg
        end
      end

      class MissingGitRevisionError < GitCommandError
        def initialize(command, destination_path, ref, repo)
          msg = "Revision #{ref} does not exist in the repository #{repo}. Maybe you misspelled it?"
          super command, destination_path, msg
        end
      end

      class AmbiguousGitReference < GitError
        def initialize(options)
          msg = "Specification of branch or ref with tag is ambiguous. You specified #{options.inspect}"
          super msg
        end
      end

      # The GitProxy is responsible to interact with git repositories.
      # All actions required by the Git source is encapsulated in this
      # object.
      class GitProxy
        attr_accessor :path, :uri, :branch, :tag, :ref, :explicit_ref
        attr_writer :revision

        def self.version
          @version ||= full_version[/((\.?\d+)+).*/, 1]
        end

        def self.full_version
          @full_version ||= begin
            raise GitNotInstalledError.new unless Bundler.git_present?

            require "open3"
            out, err, status = Open3.capture3("git", "--version")

            raise GitCommandError.new("--version", SharedHelpers.pwd, err) unless status.success?
            Bundler.ui.warn err unless err.empty?

            out.sub(/git version\s*/, "").strip
          end
        end

        def self.reset
          @version = nil
          @full_version = nil
        end

        def initialize(path, uri, options = {}, revision = nil, git = nil)
          @path     = path
          @uri      = uri
          @tag      = options["tag"]
          @branch   = options["branch"]
          @ref      = options["ref"]
          if @tag
            raise AmbiguousGitReference.new(options) if @branch || @ref
            @explicit_ref = @tag
          else
            @explicit_ref = @ref || @branch
          end
          @revision = revision
          @git      = git
          @commit_ref = nil
        end

        def revision
          @revision ||= allowed_with_path { find_local_revision }
        end

        def current_branch
          @current_branch ||= with_path do
            git_local("rev-parse", "--abbrev-ref", "HEAD", dir: path).strip
          end
        end

        def contains?(commit)
          allowed_with_path do
            result, status = git_null("branch", "--contains", commit, dir: path)
            status.success? && result.match?(/^\* (.*)$/)
          end
        end

        def version
          self.class.version
        end

        def full_version
          self.class.full_version
        end

        def checkout
          return if has_revision_cached?

          Bundler.ui.info "Fetching #{credential_filtered_uri}"

          extra_fetch_needed = clone_needs_extra_fetch?
          unshallow_needed = clone_needs_unshallow?
          return unless extra_fetch_needed || unshallow_needed

          git_remote_fetch(unshallow_needed ? ["--unshallow"] : depth_args)
        end

        def copy_to(destination, submodules = false)
          unless File.exist?(destination.join(".git"))
            begin
              SharedHelpers.filesystem_access(destination.dirname) do |p|
                FileUtils.mkdir_p(p)
              end
              SharedHelpers.filesystem_access(destination) do |p|
                FileUtils.rm_rf(p)
              end
              git "clone", "--no-checkout", "--quiet", path.to_s, destination.to_s
              # The copy is cloned from the local bare cache, which holds no Git LFS
              # objects, so point origin back at the real remote and let git-lfs derive
              # its endpoint from there when checking out. Use the credential-filtered
              # URI to avoid persisting secrets in the copy's .git/config; auth is left
              # to git's credential helper.
              git "remote", "set-url", "origin", credential_filtered_uri, dir: destination
              File.chmod((File.stat(destination).mode | 0o777) & ~File.umask, destination)
            rescue Errno::EEXIST => e
              file_path = e.message[%r{.*?((?:[a-zA-Z]:)?/.*)}, 1]
              raise GitError, "Bundler could not install a gem because it needs to " \
                "create a directory, but a file exists - #{file_path}. Please delete " \
                "this file and try again."
            end
          end

          ref = @commit_ref || (locked_to_full_sha? && @revision)
          if ref
            git "config", "uploadpack.allowAnySHA1InWant", "true", dir: path.to_s if @commit_ref.nil? && needs_allow_any_sha1_in_want?

            git "fetch", "--force", "--quiet", *extra_fetch_args(ref), dir: destination
          end

          git "reset", "--hard", revision, dir: destination

          if submodules
            git_retry "submodule", "update", "--init", "--recursive", dir: destination
          elsif Gem::Version.create(version) >= Gem::Version.create("2.9.0")
            inner_command = "git -C $toplevel submodule deinit --force $sm_path"
            git_retry "submodule", "foreach", "--quiet", inner_command, dir: destination
          end
        end

        def installed_to?(destination)
          # if copy_to is interrupted, it may leave a partially installed directory that
          # contains .git but no other files -- consider this not to be installed
          Dir.exist?(destination) && (Dir.children(destination) - [".git"]).any?
        end

        private

        def git_remote_fetch(args)
          command = fetch_command(args)
          command_with_no_credentials = check_allowed(command)

          Bundler::Retry.new("`#{command_with_no_credentials}` at #{path}", [MissingGitRevisionError]).attempts do
            out, err, status = capture(command, path)
            return out if status.success?

            if err.include?("couldn't find remote ref") || err.include?("not our ref")
              default_branch = renamed_remote_default_branch if tracking_remote_default_branch?
              if default_branch
                out = follow_remote_default_branch(args, default_branch)
                return out if out
              end

              raise MissingGitRevisionError.new(command_with_no_credentials, path, commit || explicit_ref || current_branch, credential_filtered_uri)
            else
              if shallow?
                args -= depth_args
                command = fetch_command(args)
                command_with_no_credentials = check_allowed(command)
              end
              raise GitCommandError.new(command_with_no_credentials, path, err)
            end
          end
        end

        def clone_needs_extra_fetch?
          return true if path.exist?

          SharedHelpers.filesystem_access(path.dirname) do |p|
            FileUtils.mkdir_p(p)
          end

          clone_args = extra_clone_args
          command = clone_command(clone_args)
          command_with_no_credentials = check_allowed(command)

          Bundler::Retry.new("`#{command_with_no_credentials}`", [MissingGitRevisionError]).attempts do
            _, err, status = capture(command, nil)
            return extra_ref if status.success?

            if err.include?("Could not find remote branch") || # git up to 2.49
               err.include?("Remote branch #{branch_option} not found") # git 2.49 or higher
              raise MissingGitRevisionError.new(command_with_no_credentials, nil, explicit_ref, credential_filtered_uri)
            else
              if shallow?
                clone_args -= depth_args
                command = clone_command(clone_args)
                command_with_no_credentials = check_allowed(command)
              end
              raise GitCommandError.new(command_with_no_credentials, path, err)
            end
          end
        end

        def clone_needs_unshallow?
          return false unless path.join("shallow").exist?
          return true unless shallow?

          @revision && @revision != head_revision
        end

        def extra_ref
          return false if not_pinned?
          return true if shallow?

          ref.start_with?("refs/")
        end

        def depth
          return @depth if defined?(@depth)

          @depth = if !supports_fetching_unreachable_refs?
            nil
          elsif not_pinned? || pinned_to_full_sha?
            1
          elsif ref.include?("~")
            parsed_depth = ref.split("~").last
            parsed_depth.to_i + 1
          end
        end

        def refspec
          if commit
            @commit_ref = "refs/#{commit}-sha"
            return "#{commit}:#{@commit_ref}"
          end

          reference = fully_qualified_ref

          reference ||= if ref.include?("~")
            ref.split("~").first
          elsif ref.start_with?("refs/")
            ref
          else
            "refs/*"
          end

          "#{reference}:#{reference}"
        end

        def commit
          @commit ||= pinned_to_full_sha? ? ref : @revision
        end

        def fully_qualified_ref
          if branch
            "refs/heads/#{branch}"
          elsif tag
            "refs/tags/#{tag}"
          elsif ref.nil?
            "refs/heads/#{current_branch}"
          end
        end

        def not_pinned?
          branch_option || ref.nil?
        end

        def tracking_remote_default_branch?
          explicit_ref.nil? && commit.nil?
        end

        # Returns nil on any failure, leaving HEAD untouched so the caller reports
        # the original fetch failure. Runs inside the retry block, so it must not
        # touch the caller's command locals.
        def follow_remote_default_branch(args, default_branch)
          reference = "refs/heads/#{default_branch}"
          command = fetch_command(args, "#{reference}:#{reference}")
          check_allowed(command)

          out, err, status = capture(command, path)
          unless status.success?
            Bundler.ui.debug "Could not fetch #{reference} from #{credential_filtered_uri}: #{err}"
            return
          end

          previous_branch = current_branch
          begin
            git "symbolic-ref", "HEAD", reference, dir: path
          rescue GitError => e
            Bundler.ui.debug "Could not repoint the cached clone at #{reference}: #{e.message}"
            return
          end
          @current_branch = nil
          Bundler.ui.warn "#{credential_filtered_uri} no longer has #{previous_branch}, " \
            "now following its default branch #{default_branch}"
          out
        end

        # The cached clone's HEAD branch is gone from the remote, so the remote's
        # own idea of its default branch is the only thing left to follow.
        def renamed_remote_default_branch
          default_branch = remote_default_branch
          return if default_branch.nil? || default_branch == current_branch

          default_branch
        end

        def remote_default_branch
          command = ["ls-remote", "--symref", "--", configured_uri, "HEAD"]
          check_allowed(command)

          out, err, status = capture(command, path)
          unless status.success?
            Bundler.ui.debug "Could not ask #{credential_filtered_uri} for its default branch: #{err}"
            return
          end

          # A remote is free to advertise a ref name that is not valid UTF-8, and
          # matching that as text raises out of the GitError family.
          out.b[%r{^ref:\s+refs/heads/(.+?)\s+HEAD}, 1]
        end

        def pinned_to_full_sha?
          full_sha_revision?(ref)
        end

        def locked_to_full_sha?
          full_sha_revision?(@revision)
        end

        def full_sha_revision?(ref)
          ref&.match?(/\A\h{40}\z/)
        end

        def git_null(*command, dir: nil)
          check_allowed(command)

          capture(command, dir, ignore_err: true)
        end

        def git_retry(*command, dir: nil)
          command_with_no_credentials = check_allowed(command)

          Bundler::Retry.new("`#{command_with_no_credentials}` at #{dir || SharedHelpers.pwd}").attempts do
            git(*command, dir: dir)
          end
        end

        def git(*command, dir: nil)
          run_command(*command, dir: dir) do |unredacted_command|
            check_allowed(unredacted_command)
          end
        end

        def git_local(*command, dir: nil)
          run_command(*command, dir: dir) do |unredacted_command|
            redact_and_check_presence(unredacted_command)
          end
        end

        def has_revision_cached?
          return unless commit && path.exist?
          git("cat-file", "-e", commit, dir: path)
          true
        rescue GitError
          false
        end

        def find_local_revision
          return head_revision if explicit_ref.nil?

          find_revision_for(explicit_ref)
        end

        def head_revision
          verify("HEAD")
        end

        def find_revision_for(reference)
          verify(reference)
        rescue GitCommandError => e
          raise MissingGitRevisionError.new(e.command, path, reference, credential_filtered_uri)
        end

        def verify(reference)
          git("rev-parse", "--verify", reference, dir: path).strip
        end

        # Adds credentials to the URI. This is the URI given to git, so it's
        # also the one command output must be filtered against.
        def configured_uri
          @configured_uri ||= if /https?:/.match?(uri)
            remote = Gem::URI(uri)
            config_auth = Bundler.settings[remote.to_s] || Bundler.settings[remote.host]
            remote.userinfo ||= config_auth
            remote.to_s
          else
            uri.to_s
          end
        end

        # Removes credentials from the URI
        def credential_filtered_uri
          URICredentialsFilter.credential_filtered_uri(uri)
        end

        def allow?
          allowed = @git ? @git.allow_git_ops? : true

          raise GitNotInstalledError.new if allowed && !Bundler.git_present?

          allowed
        end

        def with_path(&blk)
          checkout unless path.exist?
          blk.call
        end

        def allowed_with_path
          return with_path { yield } if allow?
          raise GitError, "The git source #{uri} is not yet checked out. Please run `bundle install` before trying to start your application"
        end

        def check_allowed(command)
          command_with_no_credentials = redact_and_check_presence(command)
          raise GitNotAllowedError.new(command_with_no_credentials) unless allow?
          command_with_no_credentials
        end

        def redact_and_check_presence(command)
          raise GitNotInstalledError.new unless Bundler.git_present?

          require "shellwords"
          URICredentialsFilter.credential_filtered_string("git #{command.shelljoin}", configured_uri)
        end

        def run_command(*command, dir: nil)
          command_with_no_credentials = yield(command)

          out, err, status = capture(command, dir)

          raise GitCommandError.new(command_with_no_credentials, dir || SharedHelpers.pwd, err) unless status.success?

          Bundler.ui.warn err unless err.empty?

          out
        end

        def capture(cmd, dir, ignore_err: false)
          SharedHelpers.with_clean_git_env do
            require "open3"
            out, err, status = Open3.capture3(*capture3_args_for(cmd, dir))

            filtered_out = URICredentialsFilter.credential_filtered_string(out, configured_uri)
            return [filtered_out, status] if ignore_err

            filtered_err = URICredentialsFilter.credential_filtered_string(err, configured_uri)
            [filtered_out, filtered_err, status]
          end
        end

        def capture3_args_for(cmd, dir)
          # Disable automatic maintenance so a background commit-graph write in
          # the source repo can't race the hardlinking local clone and fail with
          # "hardlink different from source".
          opts = ["-c", "gc.auto=0", "-c", "maintenance.auto=false"]

          return ["git", *opts, *cmd] unless dir

          ["git", "-C", dir.to_s, *opts, *cmd]
        end

        def extra_clone_args
          args = depth_args
          return [] if args.empty?

          args += ["--single-branch"]
          args.unshift("--no-tags") if supports_cloning_with_no_tags?

          # If there's a locked revision, no need to clone any specific branch
          # or tag, since we will end up checking out that locked revision
          # anyways.
          return args if @revision

          args += ["--branch", branch_option] if branch_option
          args
        end

        def fetch_command(args, spec = refspec)
          ["fetch", "--force", "--quiet", "--no-tags", *args, "--", configured_uri, spec].compact
        end

        def clone_command(args)
          ["clone", "--bare", "--no-hardlinks", "--quiet", *args, "--", configured_uri, path.to_s]
        end

        def depth_args
          return [] unless shallow?

          ["--depth", depth.to_s]
        end

        def extra_fetch_args(ref)
          extra_args = [path.to_s, *depth_args]
          extra_args.push(ref)
          extra_args
        end

        def branch_option
          branch || tag
        end

        def shallow?
          !depth.nil?
        end

        def needs_allow_any_sha1_in_want?
          @needs_allow_any_sha1_in_want ||= Gem::Version.new(version) <= Gem::Version.new("2.13.7")
        end

        def supports_fetching_unreachable_refs?
          @supports_fetching_unreachable_refs ||= Gem::Version.new(version) >= Gem::Version.new("2.5.0")
        end

        def supports_cloning_with_no_tags?
          @supports_cloning_with_no_tags ||= Gem::Version.new(version) >= Gem::Version.new("2.14.0-rc0")
        end
      end
    end
  end
end
