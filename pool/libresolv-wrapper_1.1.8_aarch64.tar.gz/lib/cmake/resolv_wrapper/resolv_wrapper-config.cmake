set(RESOLV_WRAPPER_LIBRARY /data/data/com.termibash/files/usr/lib/libresolv_wrapper.so)
