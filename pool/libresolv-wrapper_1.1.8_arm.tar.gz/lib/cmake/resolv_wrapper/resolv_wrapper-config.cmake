set(RESOLV_WRAPPER_LIBRARY /data/data/com.cyberkk.tanside/files/usr/lib/libresolv_wrapper.so)
