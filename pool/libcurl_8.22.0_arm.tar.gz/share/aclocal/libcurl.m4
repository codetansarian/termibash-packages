#***************************************************************************
#                                  _   _ ____  _
#  Project                     ___| | | |  _ \| |
#                             / __| | | | |_) | |
#                            | (__| |_| |  _ <| |___
#                             \___|\___/|_| \_\_____|
#
# Copyright (C) David Shaw <dshaw@jabberwocky.com>
#
# This software is licensed as described in the file COPYING, which
# you should have received as part of this distribution. The terms
# are also available at https://curl.se/docs/copyright.html.
#
# You may opt to use, copy, modify, merge, publish, distribute and/or sell
# copies of the Software, and permit persons to whom the Software is
# furnished to do so, under the terms of the COPYING file.
#
# This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
# KIND, either express or implied.
#
# SPDX-License-Identifier: curl
#
#***************************************************************************
# LIBCURL_CHECK_CONFIG([DEFAULT-ACTION], [MINIMUM-VERSION],
#                      [ACTION-IF-YES], [ACTION-IF-NO])
# ----------------------------------------------------------
#      David Shaw <dshaw@jabberwocky.com>   May-09-2006
#
# Checks for libcurl.  DEFAULT-ACTION is the string yes or no to
# specify whether to default to --with-libcurl or --without-libcurl.
# If not supplied, DEFAULT-ACTION is yes.  MINIMUM-VERSION is the
# minimum version of libcurl to accept.  Pass the version as a regular
# version number like 7.10.1. If not supplied, any version is
# accepted.  ACTION-IF-YES is a list of shell commands to run if
# libcurl was successfully found and passed the various tests.
# ACTION-IF-NO is a list of shell commands that are run otherwise.
# Note that using --without-libcurl does run ACTION-IF-NO.
#
# This macro #defines HAVE_LIBCURL if a working libcurl setup is
# found, and sets @LIBCURL@ and @LIBCURL_CPPFLAGS@ to the necessary
# values.  Other useful defines are LIBCURL_FEATURE_xxx where xxx are
# the various features supported by libcurl, and LIBCURL_PROTOCOL_yyy
# where yyy are the various protocols supported by libcurl.  Both xxx
# and yyy are capitalized.  See the list of AH_TEMPLATE macros at the top
# of the macro for the complete list of possible defines.  Shell
# variables $libcurl_feature_xxx and $libcurl_protocol_yyy are also
# defined to 'yes' for those features and protocols that were found.
# Note that xxx and yyy keep the same capitalization as in the
# curl-config list (e.g. it is "HTTP" and not "http").
#
# Users may override the detected values by doing something like:
# LIBCURL="-lcurl" LIBCURL_CPPFLAGS="-I/usr/myinclude" ./configure
#
# For the sake of sanity, this macro assumes that any libcurl that is found is
# after version 7.7.2, the first version that included the curl-config script.
# Note that it is important for people packaging binary versions of libcurl to
# include this script!  Without curl-config, we can only guess what protocols
# are available, or use curl_version_info to figure it out at runtime.

AC_DEFUN([LIBCURL_CHECK_CONFIG],
[
  AH_TEMPLATE([LIBCURL_FEATURE_SSL],[Defined if libcurl supports SSL])
  AH_TEMPLATE([LIBCURL_FEATURE_KRB4],[Defined if libcurl supports KRB4])
  AH_TEMPLATE([LIBCURL_FEATURE_IPV6],[Defined if libcurl supports IPv6])
  AH_TEMPLATE([LIBCURL_FEATURE_LIBZ],[Defined if libcurl supports libz])
  AH_TEMPLATE([LIBCURL_FEATURE_ASYNCHDNS],[Defined if libcurl supports AsynchDNS])
  AH_TEMPLATE([LIBCURL_FEATURE_IDN],[Defined if libcurl supports IDN])
  AH_TEMPLATE([LIBCURL_FEATURE_SSPI],[Defined if libcurl supports SSPI])
  AH_TEMPLATE([LIBCURL_FEATURE_NTLM],[Defined if libcurl supports NTLM])

  AH_TEMPLATE([LIBCURL_PROTOCOL_HTTP],[Defined if libcurl supports HTTP])
  AH_TEMPLATE([LIBCURL_PROTOCOL_HTTPS],[Defined if libcurl supports HTTPS])
  AH_TEMPLATE([LIBCURL_PROTOCOL_FTP],[Defined if libcurl supports FTP])
  AH_TEMPLATE([LIBCURL_PROTOCOL_FTPS],[Defined if libcurl supports FTPS])
  AH_TEMPLATE([LIBCURL_PROTOCOL_FILE],[Defined if libcurl supports FILE])
  AH_TEMPLATE([LIBCURL_PROTOCOL_TELNET],[Defined if libcurl supports TELNET])
  AH_TEMPLATE([LIBCURL_PROTOCOL_LDAP],[Defined if libcurl supports LDAP])
  AH_TEMPLATE([LIBCURL_PROTOCOL_DICT],[Defined if libcurl supports DICT])
  AH_TEMPLATE([LIBCURL_PROTOCOL_TFTP],[Defined if libcurl supports TFTP])
  AH_TEMPLATE([LIBCURL_PROTOCOL_RTSP],[Defined if libcurl supports RTSP])
  AH_TEMPLATE([LIBCURL_PROTOCOL_POP3],[Defined if libcurl supports POP3])
  AH_TEMPLATE([LIBCURL_PROTOCOL_IMAP],[Defined if libcurl supports IMAP])
  AH_TEMPLATE([LIBCURL_PROTOCOL_SMTP],[Defined if libcurl supports SMTP])

  AC_ARG_WITH(libcurl,
    AS_HELP_STRING([--with-libcurl=PREFIX],[look for the curl library in PREFIX/lib and headers in PREFIX/include]),
    [_libcurl_with=$withval],[_libcurl_with=ifelse([$1],,[yes],[$1])])

  if test "x$_libcurl_with" != "xno"; then

    AC_PROG_AWK

    _libcurl_version_parse="eval $AWK '{split(\$NF,A,\".\"); X=256*256*A[[1]]+256*A[[2]]+A[[3]]; print X;}'"

    _libcurl_try_link=yes

    if test -d "$_libcurl_with"; then
      LIBCURL_CPPFLAGS="-I$withval/include"
      _libcurl_ldflags="-L$withval/lib"
      AC_PATH_PROG([_libcurl_config],[curl-config],[],["$withval/bin"])
    else
      AC_PATH_PROG([_libcurl_config],[curl-config],[],[$PATH])
    fi

    if test -n "$_libcurl_config"; then
      AC_CACHE_CHECK([for the version of libcurl],
        [libcurl_cv_lib_curl_version],
        [libcurl_cv_lib_curl_version=`$_libcurl_config --version | $AWK '{print $[]2}'`])

      _libcurl_version=`echo $libcurl_cv_lib_curl_version | $_libcurl_version_parse`
      _libcurl_wanted=`echo ifelse([$2],,[0],[$2]) | $_libcurl_version_parse`

      if test "$_libcurl_wanted" -gt 0; then
        AC_CACHE_CHECK([for libcurl >= version $2],
          [libcurl_cv_lib_version_ok],
          [
          if test "$_libcurl_version" -ge "$_libcurl_wanted"; then
            libcurl_cv_lib_version_ok=yes
          else
            libcurl_cv_lib_version_ok=no
          fi
          ])
      fi

      if test "$_libcurl_wanted" -eq 0 || test "$libcurl_cv_lib_version_ok" = "yes"; then
        if test -z "$LIBCURL_CPPFLAGS"; then
          LIBCURL_CPPFLAGS=`$_libcurl_config --cflags`
        fi
        if test -z "$LIBCURL"; then
          LIBCURL=`$_libcurl_config --libs`

          dnl This is so silly, but Apple actually has a bug in their
          dnl curl-config script.  Fixed in Tiger, but there are still
          dnl lots of Panther installs around.
          case "${host}" in
            powerpc-apple-darwin7*)
              LIBCURL=`echo $LIBCURL | sed -e 's|-arch i386||g'`
              ;;
          esac
        fi

        dnl All curl-config scripts support --feature
        _libcurl_features=`$_libcurl_config --feature`

        dnl Is it modern enough to have --protocols? (7.12.4)
        if test "$_libcurl_version" -ge 461828; then
          _libcurl_protocols=`$_libcurl_config --protocols`
        fi
      else
        _libcurl_try_link=no
      fi

      unset _libcurl_wanted
    fi

    if test "$_libcurl_try_link" = "yes"; then

      dnl we did not find curl-config, so let's see if the user-supplied
      dnl link line (or failing that, "-lcurl") is enough.
      LIBCURL=${LIBCURL-"$_libcurl_ldflags -lcurl"}

      AC_CACHE_CHECK([whether libcurl is usable],
        [libcurl_cv_lib_curl_usable],
        [
        _libcurl_save_cppflags=$CPPFLAGS
        CPPFLAGS="$LIBCURL_CPPFLAGS $CPPFLAGS"
        _libcurl_save_libs=$LIBS
        LIBS="$LIBCURL $LIBS"

        AC_LINK_IFELSE([AC_LANG_PROGRAM([[#include <curl/curl.h>]],[[
          /* Try to use a few common options to force a failure if we are
             missing symbols or cannot link. */
          int x;
          curl_easy_setopt(NULL,CURLOPT_URL,NULL);
          x=CURL_ERROR_SIZE;
          x=CURLOPT_WRITEFUNCTION;
          x=CURLOPT_WRITEDATA;
          x=CURLOPT_ERRORBUFFER;
          x=CURLOPT_STDERR;
          x=CURLOPT_VERBOSE;
          if(x) {;}
        ]])],libcurl_cv_lib_curl_usable=yes,libcurl_cv_lib_curl_usable=no)

        CPPFLAGS=$_libcurl_save_cppflags
        LIBS=$_libcurl_save_libs
        unset _libcurl_save_cppflags
        unset _libcurl_save_libs
        ])

      if test "$libcurl_cv_lib_curl_usable" = "yes"; then

        dnl Does curl_free() exist in this version of libcurl?
        dnl If not, fake it with free()

        _libcurl_save_cppflags=$CPPFLAGS
        CPPFLAGS="$CPPFLAGS $LIBCURL_CPPFLAGS"
        _libcurl_save_libs=$LIBS
        LIBS="$LIBS $LIBCURL"

        AC_CHECK_DECL([curl_free],[],
          [AC_DEFINE([curl_free],[free],
            [Define curl_free() as free() if our version of curl lacks curl_free.])],
          [[#include <curl/curl.h>]])

        CPPFLAGS=$_libcurl_save_cppflags
        LIBS=$_libcurl_save_libs
        unset _libcurl_save_cppflags
        unset _libcurl_save_libs

        AC_DEFINE(HAVE_LIBCURL,1,
          [Define to 1 if you have a functional curl library.])
        AC_SUBST(LIBCURL_CPPFLAGS)
        AC_SUBST(LIBCURL)

        for _libcurl_feature in $_libcurl_features; do
          AC_DEFINE_UNQUOTED(AS_TR_CPP(libcurl_feature_$_libcurl_feature),[1])
          eval AS_TR_SH(libcurl_feature_$_libcurl_feature)=yes
        done

        if test -z "$_libcurl_protocols"; then

          dnl We do not have --protocols; assume that all
          dnl protocols are available
          _libcurl_protocols="HTTP FTP FILE TELNET LDAP DICT TFTP"

          if test "$libcurl_feature_SSL" = "yes"; then
            _libcurl_protocols="$_libcurl_protocols HTTPS"

            dnl FTPS was not standards-compliant until version
            dnl 7.11.0 (0x070b00 == 461568)
            if test "$_libcurl_version" -ge 461568; then
              _libcurl_protocols="$_libcurl_protocols FTPS"
            fi
          fi

          dnl RTSP, IMAP, POP3 and SMTP were added in
          dnl 7.20.0 (0x071400 == 463872)
          if test "$_libcurl_version" -ge 463872; then
            _libcurl_protocols="$_libcurl_protocols RTSP IMAP POP3 SMTP"
          fi
        fi

        for _libcurl_protocol in $_libcurl_protocols; do
          AC_DEFINE_UNQUOTED(AS_TR_CPP(libcurl_protocol_$_libcurl_protocol),[1])
          eval AS_TR_SH(libcurl_protocol_$_libcurl_protocol)=yes
        done
      else
        unset LIBCURL
        unset LIBCURL_CPPFLAGS
      fi
    fi

    unset _libcurl_try_link
    unset _libcurl_version_parse
    unset _libcurl_config
    unset _libcurl_feature
    unset _libcurl_features
    unset _libcurl_protocol
    unset _libcurl_protocols
    unset _libcurl_version
    unset _libcurl_ldflags
  fi

  if test "x$_libcurl_with" = "xno" || test "$libcurl_cv_lib_curl_usable" != "yes"; then
    dnl This is the IF-NO path
    ifelse([$4],,:,[$4])
  else
    dnl This is the IF-YES path
    ifelse([$3],,:,[$3])
  fi

  unset _libcurl_with
])
